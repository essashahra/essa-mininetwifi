Codes now available at: https://github.com/ramonfontes/reproducible-research
